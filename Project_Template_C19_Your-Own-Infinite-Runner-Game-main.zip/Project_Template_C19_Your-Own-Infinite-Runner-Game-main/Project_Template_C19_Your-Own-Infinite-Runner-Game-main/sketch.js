var astronauta, astronautaIMG;
var fundo_estrelas, fundo_estrelasIMG;
var asteroide, asteroideIMG, GrupoAsteroides;
var estadoDoJogo = "play";
var pontuacao = 0;

function preload(){

 astronautaIMG = loadImage("astronauta.png");
 fundo_estrelasIMG = loadImage("fundo_estrelas.jpg");
 asteroideIMG = loadImage("asteroide.png");

}

function setup() {
 createCanvas(400,400);

 fundo_estrelas = createSprite(200,200,400,400);
 fundo_estrelas.addImage("estrelas", fundo_estrelasIMG);
 fundo_estrelas.scale = 3.0;

 GrupoAsteroides = new Group();

 astronauta = createSprite(200,200);
 astronauta.addImage(astronautaIMG);
 astronauta.scale = 0.05;
 
}

function draw() {
 background("black");

 if(estadoDoJogo === "play"){

 fundo_estrelas.velocityY = -3;

 if(fundo_estrelas.y < 150){
  fundo_estrelas.y = 250;
 }

 if(keyDown("right_arrow")){
   astronauta.x += 5;
 }
 if(keyDown("left_arrow")){
   astronauta.x -= 5;
 }
 if(keyDown("up_arrow")){
   astronauta.y -= 5;
 }
 if(keyDown("down_arrow")){
   astronauta.y += 5;
 }

 criar_asteroide();

 if(GrupoAsteroides.isTouching(astronauta) || astronauta.x < 0 || astronauta.x > 400 || astronauta.y < 0 || astronauta.y > 400){
   GrupoAsteroides.destroyEach();
   estadoDoJogo = "end";
 }

 drawSprites();

}

if(estadoDoJogo === "end"){
  stroke("yellow")
  fill("red");
  textSize(40);
  text("Você Perdeu",90,200);
}
 
}

function criar_asteroide(){

 if(frameCount % 100 === 0){
    
  var asteroide = createSprite(200,450);
   asteroide.addImage("asteroides", asteroideIMG);
   asteroide.scale = 0.2;
   asteroide.x = Math.round(random(70,320));
   asteroide.velocityY = -4;
   astronauta.depth = asteroide.depth;
   astronauta.depth += 1;
   asteroide.lifetime = 600;
   GrupoAsteroides.add(asteroide);
    
 }

}